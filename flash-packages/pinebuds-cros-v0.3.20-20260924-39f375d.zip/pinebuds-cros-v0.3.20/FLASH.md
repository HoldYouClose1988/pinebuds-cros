# PineBuds Pro flash package **v0.3.20** (stage-b)

DIY / own-risk. **Experimental CROS — not a hearing aid or PPE.** Keep a stock backup.

Start here → **`BESTOOL.md`** (flasher) and **`RELEASE_NOTES.txt`** (this version).

## What’s in this zip

| File | Purpose |
|------|---------|
| `VERSION` | Package version (`0.3.20`) |
| `CHANGELOG.md` | Full project changelog |
| `RELEASE_NOTES.txt` | Notes for **this** version only |
| `BESTOOL.md` | How to use the bundled `bestool.exe` |
| `bestool.exe` | Windows flasher ([Ralim/bestool](https://github.com/Ralim/bestool), MIT + BES programmer blob) |
| `NOTICE` | Third-party / SDK notices |
| `open_source.bin` | Firmware image (flash to **both** buds) |
| `flash.ps1` | Write image via `bestool` |
| `backup.ps1` | Read stock images before first custom flash |
| `MANIFEST.txt` | Build id, git sha, checksum |
| `SHA256SUMS` | SHA-256 of bin + bestool |

## One-time Windows setup

1. Install WCH **CH342** driver → Device Manager shows **two** COM ports.
2. Unzip this folder — `bestool.exe` is already included (no Rust build needed).
3. Optional restore tool: PINE64 `dld_main` + [factory images](https://wiki.pine64.org/wiki/PineBuds_Pro#Firmware_images).

If Windows Defender quarantines `bestool.exe`, restore it or allow the folder (unsigned Rust binary).

## Backup once (before any custom flash)

```powershell
# Replace COM5 / COM6 with your ports
.\backup.ps1 -Port0 COM5 -Port1 COM6
```

(`flash.ps1` / `backup.ps1` auto-find `.\bestool.exe`.)

Keep `backups\*.bin` somewhere safe.

## Flash this version (v0.3.20)

1. Unzip this folder.
2. Seat both buds; plug the case in USB.
3. Wake: remove buds ~3s and reseat, **or** long-hold rear button in-case (~5s).
4. Run:

```powershell
.\flash.ps1 -Port0 COM5 -Port1 COM6
```

(`BinPath` defaults to `.\open_source.bin`.)

5. Leave buds in case ~30–60s for TWS re-pair.

## Lost TWS link / no quad-tap

Quad-tap needs the **bud↔bud** link. If one LED stays in pairing flash:

1. Forget PineBuds Pro on the phone.
2. Both in case + USB: hold **case RESET ~5s**, wait 30–60s (purple LED not required).
3. If still unpaired: power each off (hold ~5s to red), both red+blue → tap 5×, seat 30s+.
4. Last resort: factory restore via `dld_main`, confirm stock TWS, re-flash this zip.

## Experimental CROS test (this build)

After both buds re-pair (~30s):

- Wear **both** buds. **Quad-tap** either bud to toggle CROS (needs TWS link).
- Default: **RIGHT = mic (poor / TX)**, **LEFT = speaker (good / RX)**.
- Speak / scratch near the **right** outer face — hear it in the **left** ear.
- Path: 50 ms ADPCM on BESAUD **extra L2CAP** after peer READY; cmd fallback until then.
- Avoid phone music while testing (A2DP fights the CROS stream).

**Phone logs (TOTA=1):** open `android/cros-log` → Connect → **Capture logs** on.
Expect handshake lines then `[cros_log] quiet=1` — periodic stats are suppressed on
purpose so SPP does not kill extra audio. Transitions (READY / DISABLE) still show.
Share log from the app when done.

DIY / own-risk — **not** a hearing aid.

## Flash budget

On-chip flash has limited erase cycles (~500). Flash only when you mean to.

## Feedback

If you test a build, note: left/right master, worn vs desk, chop y/n, delay feel, Capture on/off, version from `init v0.x.x` log line.
