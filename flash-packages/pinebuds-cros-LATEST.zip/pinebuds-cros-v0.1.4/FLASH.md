# PineBuds Pro flash package **v0.1.4** (stage-a)

DIY / own-risk. **Work in progress — not a functional CROS product.** Not a hearing aid or PPE.

Start here → read **`BESTOOL.md`** (install flasher) and **`RELEASE_NOTES.txt`** (what changed).

## What’s in this zip

| File | Purpose |
|------|---------|
| `VERSION` | Package version (`0.1.4`) |
| `CHANGELOG.md` | Full project changelog |
| `RELEASE_NOTES.txt` | Notes for **this** version only |
| `BESTOOL.md` | Install + use `bestool.exe` on Windows |
| `open_source.bin` | Firmware image (flash to **both** buds) |
| `flash.ps1` | Write image via `bestool` |
| `backup.ps1` | Read stock images before first custom flash |
| `MANIFEST.txt` | Build id, git sha, checksum |
| `SHA256SUMS` | SHA-256 of the bin |

## One-time Windows setup

1. Install WCH **CH342** driver → Device Manager shows **two** COM ports.
2. Follow **`BESTOOL.md`** to build `bestool.exe` and put it on PATH (or copy next to these scripts).
3. Optional restore tool: PINE64 `dld_main` + [factory images](https://wiki.pine64.org/wiki/PineBuds_Pro#Firmware_images).

## Backup once (before any custom flash)

```powershell
# Replace COM5 / COM6 with your ports
.\backup.ps1 -Port0 COM5 -Port1 COM6 -Bestool .\bestool.exe
```

Keep `backups\*.bin` somewhere safe.

## Flash this version (v0.1.4)

1. Unzip this folder.
2. Seat both buds; plug the case in USB.
3. Wake: remove buds ~3s and reseat, **or** long-hold rear button in-case (~5s).
4. Run:

```powershell
.\flash.ps1 -Port0 COM5 -Port1 COM6 -Bestool .\bestool.exe
```

(`BinPath` defaults to `.\open_source.bin`.)

5. Leave buds in case ~30s for TWS re-pair.

## Experimental loopback test (if enabled in this build)

Only if this package was built with the experimental same-bud mic loopback:

- Wear the bud (open-air desk tests can howl).
- Avoid playing phone music during the test (A2DP can fight the loopback streams).
- Sound near the **outer** face (FF mic) may be heard in that ear with delay.
- **Quad-tap** may toggle loopback off/on.
- This is **not** CROS to the other ear.

## Flash budget

On-chip flash has limited erase cycles (~500). Flash only when you mean to.

## Feedback

If you test a build, note: left/right, worn vs desk, howl y/n, toggle y/n, phone paired y/n.
