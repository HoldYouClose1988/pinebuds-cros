# PineBuds Pro BiCROS flash package **v0.3.66** (stage-b)

DIY / own-risk. **Experimental BiCROS — not a hearing aid or PPE.** Keep a stock backup.

## Start here (easiest)

1. Unzip this **entire** folder.
2. Plug the charging case into USB (need **two** COM ports — install the [WCH CH342 driver](http://www.wch-ic.com/downloads/CH343SER_EXE.html) if missing).
3. Right-click `Install.ps1` → **Run with PowerShell**  
   (or: `powershell -ExecutionPolicy Bypass -File .\Install.ps1`).
4. Follow the on-screen menu: **Backup THEN flash** the first time.
5. Leave both buds in the case **30–60 s** for TWS re-pair.
6. Pair an **Android** phone. **Quad-tap** toggles BiCROS.
7. Sideload `CROScontrol.apk` for knobs / Help (optional but recommended).

If Windows blocks the script: `Set-ExecutionPolicy -Scope Process Bypass` then re-run `Install.ps1`.  
If Defender quarantines `bestool.exe`, restore/allow it (unsigned Rust binary).

Also see **`BESTOOL.md`** (Sync detail) and **`RELEASE_NOTES.txt`** (this version).

## What’s in this zip

| File | Purpose |
|------|---------|
| `Install.ps1` | **Guided installer** — instructions + backup/flash menu + COM detect |
| `VERSION` | Package version (`0.3.66`) |
| `CHANGELOG.md` | Full project changelog |
| `RELEASE_NOTES.txt` | Notes for **this** version only |
| `BESTOOL.md` | How to use the bundled `bestool.exe` |
| `bestool.exe` | Windows flasher ([Ralim/bestool](https://github.com/Ralim/bestool), MIT + BES programmer blob) |
| `NOTICE` | Third-party / SDK notices |
| `open_source.bin` | Firmware image (flash to **both** buds) |
| `flash.ps1` | Write image via `bestool` (auto-detects COM if omitted) |
| `backup.ps1` | Read stock images before first custom flash |
| `CROScontrol.apk` | Android **CROS Control** app (sideload — not on Play Store) |
| `MANIFEST.txt` | Build id, git sha, checksum |
| `SHA256SUMS` | SHA-256 of bin + bestool + APK |

## Critical: Sync order (every bud)

BES2300 only enters the programmer if Sync is ACKed **during reset**:

1. Bud **OUT** (LED awake).
2. Press Enter in the script (Sync starts).
3. **Immediately reseat** that bud.

Do **one** bud at a time. Hang on `Sent message type Sync` → Ctrl+C and retry.

## Manual backup / flash (advanced)

```powershell
# Ports optional if exactly two COM devices are present
.\backup.ps1 -Port0 COM5 -Port1 COM6
.\flash.ps1  -Port0 COM5 -Port1 COM6
```

(`BinPath` defaults to `.\open_source.bin`. Scripts auto-find `.\bestool.exe`.)

Keep `backups\*.bin` somewhere safe.

## Install the Android app (sideload)

1. Copy `CROScontrol.apk` from this folder to your **Android** phone.
2. On the phone, allow *Install unknown apps* for Files / Chrome / your file manager.
3. Open the APK → Install.
4. Pair **PineBuds Pro** in Bluetooth settings, then open **CROS Control** → Connect → **Apply** knobs once.
5. After Apply, settings live on the buds — quad-tap works without the app open.

App source (build yourself if you prefer): `android/cros-log/` on GitHub.

**iPhone is not supported** for day-to-day BiCROS.

## Lost TWS link / no quad-tap

Quad-tap needs the **bud↔bud** link. If one LED stays in pairing flash:

1. Forget PineBuds Pro on the phone.
2. Both in case + USB: hold **case RESET ~5s**, wait 30–60s (purple LED not required).
3. If still unpaired: power each off (hold ~5s to red), both red+blue → tap 5×, seat 30s+.
4. Last resort: factory restore via PINE64 `dld_main`, confirm stock TWS, re-flash this zip.

## Experimental BiCROS test (this build)

After both buds re-pair (~30s):

- Wear **both** buds. **Quad-tap** either bud to toggle BiCROS (needs TWS link).
- Default: **RIGHT = mic (poor / TX)**, **LEFT = speaker (good / RX)** — change poor side in the app.
- Speak / scratch near the poor outer face — hear it in the good ear.
- Path: peer SCO mSBC BiCROS (~140 ms) + local good-ear sidetone mix.
- **Turning BiCROS off/on can take ~15–40 s.** That wait is intentional — do not
  case-reset mid-wait unless it truly wedges.
- Avoid phone music while testing (A2DP fights the BiCROS stream).
- **Disable BiCROS before taking a phone call.**

DIY / own-risk — **not** a hearing aid.

## Flash budget

On-chip flash has limited erase cycles (~500). Flash only when you mean to.
